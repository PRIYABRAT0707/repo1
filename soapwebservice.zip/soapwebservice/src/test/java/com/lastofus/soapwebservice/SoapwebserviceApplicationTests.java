package com.lastofus.soapwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapwebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
