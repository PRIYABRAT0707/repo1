package com.serviceregistry.microserviceimplementation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceimplementationApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceimplementationApplication.class, args);
	}

}
